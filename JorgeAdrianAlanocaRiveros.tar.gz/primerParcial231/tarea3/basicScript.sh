echo "dame tu nombre"
read estudiante;
echo "hola $estudiante un gusto"
mkdir ubicaciones
cd ubicaciones
touch ubicacion.txt
pwd > ubicacion.txt
cd ..
touch fechaTarea3.txt
date > fechaTarea3.txt
ls -l /home/adrian/Descargas/primerParcial231/tarea3/
echo "se finalizo el script"
